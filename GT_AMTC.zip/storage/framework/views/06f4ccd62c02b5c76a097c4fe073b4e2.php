<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section class="dark:bg-primary-200 p-10 dark:text-white">
        <h1 class="text-3xl font-bold mb-2"><?php echo e(__('Who\'s in the lead?')); ?></h1>
        <p class="text-lg"><?php echo e(__('See who\'s ahead, who\'s catching up, and who\'s next to take the podium')); ?></p>
    </section>

    <section class="container mx-auto px-4 py-8">
        <!-- Two-column layout for leaderboards -->
        <div class="flex flex-col lg:flex-row gap-8">
            <!-- Final Tournament Leaderboard Column -->
            <div class="lg:w-1/2">

                <?php if(isset($finalLeaderboard) && $finalLeaderboard->count()): ?>
                    <div class="bg-secondary-100 p-6 rounded-lg shadow-lg">
                        <h1 class="text-white text-3xl font-bold mb-4"><?php echo e($finalTournament->title); ?> - <?php echo e(__('Final Results')); ?></h1>

                        <div class="hidden sm:grid grid-cols-12 gap-4 px-2 py-2 border-b border-gray-700">
                            <div class="col-span-1 text-white font-bold text-center">#</div>
                            <div class="col-span-6 text-white font-bold"><?php echo e(__('Driver')); ?></div>
                            <div class="col-span-2 text-white font-bold text-center"><?php echo e(__('Time')); ?></div>
                            <div class="col-span-3 text-white font-bold text-center"><?php echo e(__('Points')); ?></div>
                        </div>

                        <?php $__currentLoopData = $finalLeaderboard; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php
                                $minutes = floor($participant->time_taken / 60);
                                $seconds = $participant->time_taken % 60;
                            ?>
                            <div class="grid grid-cols-1 sm:grid-cols-12 gap-4 items-center border-b border-gray-700 p-3">
                                <div class="sm:col-span-1 text-white text-xl font-bold text-center"><?php echo e($participant->position); ?></div>
                                <div class="sm:col-span-6 flex items-center gap-3">
                                    <img src="<?php echo e($participant->user->profile_photo_path ?? 'https://ui-avatars.com/api/?name=' . urlencode($participant->user->name)); ?>"
                                         class="w-10 h-10 rounded-full object-cover border border-white">
                                    <div class="text-white font-semibold text-lg truncate"><?php echo e($participant->user->name); ?></div>
                                </div>
                                <div class="sm:col-span-2 text-center text-green-400 text-lg font-bold">
                                    <?php echo e(sprintf('%d:%06.3f', $minutes, $seconds)); ?>

                                </div>
                                <div class="sm:col-span-3 text-center text-white text-lg font-bold">
                                    <?php echo e($participant->points); ?>

                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                <?php endif; ?>
            </div>

            <!-- Regular Leaderboard Column -->
            <div class="lg:w-1/2">
                <div class="bg-secondary-100 p-6 rounded-lg shadow-lg">
                    <h1 class="text-white text-3xl font-bold mb-4"><?php echo e(__('Season Leaderboard')); ?></h1>

                    <!-- Location Tabs -->
                    <div x-data="{ tab: '<?php echo e(array_key_first($season_leaderboard->toArray())); ?>' }">
                        <div class="flex space-x-4 mb-6">
                            <?php $__currentLoopData = $season_leaderboard; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location => $participants): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <button
                                    @click="tab = '<?php echo e($location); ?>'"
                                    :class="tab === '<?php echo e($location); ?>'
                                        ? 'border-b-4 border-primary cursor-pointer text-red-600 font-semibold'
                                        : 'text-white cursor-pointer border-transparent'"
                                    class="py-2 px-4 transition">
                                    <?php echo e(ucfirst($location)); ?>

                                </button>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                        <!-- Leaderboard Per Location -->
                        <?php $__currentLoopData = $season_leaderboard; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $location => $participants): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div x-show="tab === '<?php echo e($location); ?>'" class="space-y-4">
                                <h2 class="text-white text-2xl font-bold mb-4"><?php echo e(ucfirst($location)); ?> Leaderboard</h2>

                                <div class="hidden sm:grid grid-cols-12 gap-4 px-2 py-2 border-b border-gray-700">
                                    <div class="col-span-1 text-white font-bold text-center">#</div>
                                    <div class="col-span-6 text-white font-bold"><?php echo e(__('Driver')); ?></div>
                                    <div class="col-span-2 text-white font-bold text-center"><?php echo e(__('Time')); ?></div>
                                    <div class="col-span-3 text-white font-bold text-center"><?php echo e(__('+Diff')); ?></div>
                                </div>

                                <?php $__currentLoopData = $participants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $participant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                        $minutes = floor($participant->avg_time / 60);
                                        $seconds = $participant->avg_time % 60;
                                        $diff = $participant->avg_time - $participants[0]->avg_time;
                                    ?>
                                    <div class="grid grid-cols-1 sm:grid-cols-12 gap-4 items-center border-b border-gray-700 p-3">
                                        <div class="sm:col-span-1 text-white text-xl font-bold text-center"><?php echo e($participant->position); ?></div>
                                        <div class="sm:col-span-6 flex items-center gap-3">
                                            <img src="<?php echo e($participant->profile_photo_path ?? 'https://ui-avatars.com/api/?name=' . urlencode($participant->name)); ?>"
                                                 alt="<?php echo e($participant->name); ?>"
                                                 class="w-10 h-10 rounded-full object-cover border border-white">
                                            <div class="text-white font-semibold text-lg truncate"><?php echo e($participant->name); ?></div>
                                        </div>
                                        <div class="sm:col-span-2 text-center text-green-400 text-lg font-bold">
                                            <?php echo e(sprintf('%d:%06.3f', $minutes, $seconds)); ?>

                                        </div>
                                        <div class="sm:col-span-3 text-center text-sm font-bold
                                            <?php echo e($diff > 0 ? 'text-red-400' : 'text-green-400'); ?>">
                                            <?php echo e($diff > 0 ? '+' : ''); ?><?php echo e(number_format($diff, 3)); ?>s
                                        </div>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\yagou\Desktop\GT_AMTC\resources\views/leaderboard/index.blade.php ENDPATH**/ ?>