<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <section class="dark:bg-primary-200 p-10 dark:text-white">
        <h1 class="text-3xl font-bold mb-2"><?php echo e(__('Who\'s in the lead?')); ?></h1>
        <p class="text-lg"><?php echo e(__('See who’s ahead, who’s catching up, and who’s next to take the podium')); ?></p>
    </section>
    <section class="bg-secondary-100 p-10">
        <h1 class="text-white text-4xl font-bold mb-2"><?php echo e(__('Results & Leaderboard')); ?></h1>
        <p class="text-secondary-300 text-xl mb-10"><?php echo e($tournament->title); ?></p>

        <section class="flex flex-col lg:flex-row w-full gap-4 lg:gap-10">
            <!-- Real-Time Results Section -->
            <section class="bg-black w-full rounded-lg px-4 sm:px-6 py-4">
                <div class="flex items-center justify-between mb-4 sm:mb-6">
                    <h2 class="text-white text-xl sm:text-2xl lg:text-3xl font-bold"><?php echo e(__('Real-Time Results')); ?></h2>
                </div>
                <ul class="space-y-3 sm:space-y-4">
                    <?php $__currentLoopData = $participants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="flex flex-col sm:flex-row items-start sm:items-center justify-between bg-secondary-100 p-3 sm:p-4 rounded-lg sm:rounded-xl shadow">
                            <!-- Left: Rank, Image, Name, Location -->
                            <div class="flex items-center gap-3 w-full sm:w-auto mb-2 sm:mb-0">
                                <div class="text-white text-xl sm:text-2xl font-bold w-4 sm:w-6"><?php echo e($participant->position); ?></div>
                                <img src="<?php echo e($participant->user->avatar_url ?? 'https://ui-avatars.com/api/?name='.urlencode($participant->user->name)); ?>"
                                     alt="<?php echo e($participant->user->name); ?>"
                                     class="w-8 h-8 sm:w-10 sm:h-10 lg:w-12 lg:h-12 rounded-full object-cover border border-white">
                                <div class="overflow-hidden">
                                    <div class="text-white text-sm sm:text-base lg:text-lg font-semibold whitespace-nowrap overflow-hidden text-ellipsis"><?php echo e($participant->user->name); ?></div>
                                    <div class="text-gray-400 text-xs sm:text-sm"><?php echo e(__($participant->location)); ?></div>
                                </div>
                            </div>

                            <!-- Right: Time -->
                            <?php
                                $minutes = floor($participant->time_taken / 60);
                                $seconds = $participant->time_taken % 60;
                            ?>
                            <div class="text-right sm:text-left w-full sm:w-auto">
                                <div class="text-green-400 text-lg sm:text-xl lg:text-2xl font-bold whitespace-nowrap">
                                    <?php echo e(sprintf('%d:%06.3f', $minutes, $seconds)); ?>

                                </div>
                                <div class="text-xs sm:text-sm <?php echo e($participant->time_diff > 0 ? 'text-red-400' : 'text-green-400'); ?>">
                                    <?php echo e($participant->time_diff > 0 ? '+' : ''); ?><?php echo e(number_format($participant->time_diff, 3)); ?>

                                </div>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </section>

            <!-- Season Leaderboard Section -->
            <section class="bg-black w-full rounded-lg px-4 sm:px-6 py-4">
                <div class="flex flex-col sm:flex-row items-start sm:items-center justify-between mb-4 sm:mb-6 gap-2 sm:gap-0">
                    <h2 class="text-white text-xl sm:text-2xl lg:text-3xl font-bold"><?php echo e(__('Season Leaderboard')); ?></h2>
                    <div class="relative w-full sm:w-auto">
                        <form method="GET" action="<?php echo e(route('leaderboard.index')); ?>">
                            <select name="season" onchange="this.form.submit()"
                                    class="bg-secondary-100 text-white rounded-lg py-1 sm:py-2 px-2 sm:px-3 text-sm sm:text-base w-full sm:w-auto">
                                <?php $__currentLoopData = $seasons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $season): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($season->season); ?>"
                                        <?php echo e($selectedSeason == $season->season ? 'selected' : ''); ?>>
                                        Season <?php echo e($season->season); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </form>
                    </div>
                </div>

                <!-- Column Headers -->
                <div class="hidden sm:grid grid-cols-12 gap-2 lg:gap-4 mb-3 px-2 lg:px-4 py-2 border-b border-gray-700">
                    <div class="col-span-1 text-white font-bold text-center text-sm lg:text-base">Rank</div>
                    <div class="col-span-6 lg:col-span-6 text-white font-bold text-sm lg:text-base">Driver</div>
                    <div class="col-span-2 lg:col-span-2 text-white font-bold text-center text-sm lg:text-base">Wins</div>
                    <div class="col-span-3 lg:col-span-3 text-white font-bold text-center text-sm lg:text-base">Points</div>
                </div>

                <!-- Participants List -->
                <ul class="space-y-3 sm:space-y-4">
                    <?php $__currentLoopData = $season_leaderboard; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $participant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="grid grid-cols-1 sm:grid-cols-12 gap-2 lg:gap-4 items-center border-b border-gray-700 p-3 sm:p-4 shadow">
                            <!-- Rank Column -->
                            <div class="sm:col-span-1 flex sm:block items-center gap-2">
                                <span class="text-gray-400 sm:hidden text-sm">Rank:</span>
                                <span class="text-white text-lg sm:text-xl lg:text-2xl font-bold"><?php echo e($participant->position); ?></span>
                            </div>

                            <!-- Driver Column (Name + Avatar) -->
                            <div class="sm:col-span-6 flex items-center gap-3">
                                <img src="<?php echo e($participant->avatar_url ?? 'https://ui-avatars.com/api/?name='.urlencode($participant->name)); ?>"
                                     alt="<?php echo e($participant->name); ?>"
                                     class="w-8 h-8 sm:w-10 sm:h-10 lg:w-12 lg:h-12 rounded-full object-cover border border-white">
                                <div class="text-white text-sm sm:text-base lg:text-lg font-semibold overflow-hidden text-ellipsis"><?php echo e($participant->name); ?></div>
                            </div>

                            <!-- Wins Column -->
                            <div class="sm:col-span-2 flex items-center justify-center gap-2">
                                <span class="text-gray-400 sm:hidden text-sm">Wins:</span>
                                <span class="text-white text-sm sm:text-base lg:text-lg font-bold"><?php echo e($participant->wins); ?></span>
                            </div>

                            <!-- Points Column -->
                            <div class="sm:col-span-3 flex items-center justify-center gap-2">
                                <span class="text-gray-400 sm:hidden text-sm">Points:</span>
                                <span class="text-white text-sm sm:text-base lg:text-lg font-bold"><?php echo e($participant->total_points); ?></span>
                            </div>
                        </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            </section>
        </section>
    </section>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php /**PATH C:\Users\yagou\Desktop\GT_AMTC\resources\views/leaderboard/index.blade.php ENDPATH**/ ?>
