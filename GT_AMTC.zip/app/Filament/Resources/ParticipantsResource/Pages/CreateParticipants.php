<?php

namespace App\Filament\Resources\ParticipantsResource\Pages;

use App\Filament\Resources\ParticipantsResource;
use Filament\Actions;
use Filament\Resources\Pages\CreateRecord;

class CreateParticipants extends CreateRecord
{
    protected static string $resource = ParticipantsResource::class;
}
