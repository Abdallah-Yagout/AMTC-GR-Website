<?php

namespace App\Helpers;

class Location
{
    public static function cities ()
    {
        return [
            'Aden' => 'Aden',
            'Sana\'a' => 'Sana\'a',
            'Mukalla' => 'Mukalla',
        ];
    }
}
