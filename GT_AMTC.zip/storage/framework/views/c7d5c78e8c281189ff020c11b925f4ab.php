<div id="countdown" class="bg-secondary text-white py-12 px-6 text-center" dir="<?php echo e(app()->getLocale() === 'ar' ? 'rtl' : 'ltr'); ?>">
    <h2 class="text-2xl md:text-3xl font-semibold mb-1"><?php echo e(__('Next Race Event')); ?></h2>
    <p class="text-gray-400 text-sm mb-10">GR Supra GT Cup 2025 - <?php echo e(__('Round')); ?> 3</p>

    <div class="flex justify-center gap-10 text-white font-bold text-5xl">
        <?php $__currentLoopData = ['days', 'hours', 'minutes', 'seconds']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="flex flex-col items-center">
                <div class="relative w-16 h-20 overflow-hidden">
                    <div id="<?php echo e($unit); ?>-flip" class="absolute inset-0 flex items-center justify-center text-white transition-all duration-300 ease-in-out transform scale-100">
                        00
                    </div>
                </div>
                <div class="text-sm mt-2 tracking-widest uppercase text-white/80">
                    <?php if(app()->getLocale() === 'ar'): ?>
                        <?php echo e(__(ucfirst($unit))); ?>

                    <?php else: ?>
                        <?php echo e(strtoupper($unit)); ?>

                    <?php endif; ?>
                </div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php /**PATH C:\Users\yagou\Desktop\GT_AMTC\resources\views/components/countdown.blade.php ENDPATH**/ ?>